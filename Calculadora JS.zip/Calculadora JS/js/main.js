console.log("Hola Mundo")
//alert("Hola Mundo JS")

x=2
x="Hola"
console.log(x)

document.getElementById("titulo1").innerText="Hola Mundo JS"
document.getElementById("titulo1").style="color: gray; text-align: center"

titulo2=document.getElementById("titulo2")
titulo2.innerText="Turno Noche"
titulo2.style="color: red; text-align: center"


caja1=document.getElementById("caja1")
caja1.innerHTML="<h1>Caja1</h1>"
caja1.style="background-color: yellow; color: purple; padding: 5px; border-radius: 20px; text-align: center"

function rojo(){
    caja3.innerHTML="<h1>Rojo</h1>"
    caja3.style="color: white; background-color: red; text-align: center"
}

function verde(){
    caja3.innerHTML="<h1>Verde</h1>"
    caja3.style="color: white; background-color: green; text-align: center"
}

function azul(){
    caja3.innerHTML="<h1>Azul</h1>"
    caja3.style="color: white; background-color: blue; text-align: center"
}